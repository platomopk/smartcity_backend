<?php
//json format
header('Content-type:Application/json');
//including db
include 'db_connect.php';

if(isset($_GET['id']))
    { 
        $id= mysqli_real_escape_string($con, $_GET['id']);
     }
     if(isset($_GET['latlng']))
    { 
        $latlng= mysqli_real_escape_string($con, $_GET['latlng']);
     }
if(isset($_GET['speed']))
    { 
        $speed= mysqli_real_escape_string($con, $_GET['speed']);
    }
    if(isset($_GET['accelerate']))
    { 
        $accelerate= mysqli_real_escape_string($con, $_GET['accelerate']);
    }
if(isset($_GET['timestamp']))
    { 
        $timestamp= mysqli_real_escape_string($con, $_GET['timestamp']);
    }
    if(isset($_GET['altitude']))
    { 
        $altitude= mysqli_real_escape_string($con, $_GET['altitude']);
    }

//query string
$query= mysqli_query($con,
"Insert into location (TripID,LatLng,Speed,Accelerate,TimeStamp, Altitude) values
((select TripId from smartcity.trips where TripId = '$id'),'$latlng','$speed','$accelerate','$timestamp','$altitude')
");

$response = array();
    // check if row inserted or not
    if ($query) {
        $response["success"] = "Yes";
        echo json_encode($response);
    } else {
        $response["success"] = "no";
        echo json_encode($response);
    }

?>