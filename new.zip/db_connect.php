<?php
error_reporting(0);

$con=mysqli_connect('localhost','root','','smartcity') or die("We are experiencing some technical difficulties while maintaining a connection to our server. Please try again after some time.");

define( 'API_ACCESS_KEY', 'AIzaSyAol6ClRwslBrmaYmDRTswzAqPpEtgCjhM');
?>